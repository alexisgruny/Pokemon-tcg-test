export interface Cards {
   id: string;
   localId: string;
   name: string;
   image: string;
   type: string;
   category: string;
   rarity: string;
   description: string;
   setId: string;
   setName: string;
   setLogo: string;
   illustrator: string;
}